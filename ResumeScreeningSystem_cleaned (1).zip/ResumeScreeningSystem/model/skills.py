skills_list = [

    "python",
    "java",
    "c",
    "c++",
    "sql",
    "html",
    "css",
    "javascript",
    "django",
    "flask",
    "react",
    "machine learning",
    "deep learning",
    "tensorflow",
    "numpy",
    "pandas"
]


def extract_skills(text):

    found = []

    lower = text.lower()

    for skill in skills_list:

        if skill in lower:
            found.append(skill.title())

    return found