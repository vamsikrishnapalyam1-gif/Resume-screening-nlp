from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from model.preprocess import clean


def match_resume(resume, job):

    documents = [clean(resume), clean(job)]

    vectorizer = TfidfVectorizer()

    vectors = vectorizer.fit_transform(documents)

    similarity = cosine_similarity(vectors)

    return similarity[0][1]